package com.tayode.football

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val status = findViewById<TextView>(R.id.status)
        findViewById<Button>(R.id.quickMatch).setOnClickListener {
            status.text = "QUICK MATCH\n\nHome: TAYODE United\nAway: Tanzania Stars XI\n\nMatch Engine: deterministic offline simulation\nDifficulty: Normal\n\n[BUILD 01.47 ALPHA]"
        }
        findViewById<Button>(R.id.teams).setOnClickListener {
            status.text = "TEAMS & PLAYERS\n\nPlayer database is stored locally in data/players.json.\nNo internet connection is required for the Alpha build."
        }
        findViewById<Button>(R.id.settings).setOnClickListener {
            status.text = "SETTINGS\n\nGraphics: Performance\nFPS target: 30\nAudio: On\nOffline mode: ON\nMinimum Android: 9 (API 28)\nRecommended RAM: 3GB+"
        }
    }
}
