
package com.tayode.football;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(new FootballGameView(this));
    }
}

class FootballGameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random(147);
    private float sx=1, sy=1, W=1280, H=720;
    private float bx=640, by=360, ballVX=0, ballVY=0;
    private float playerX=350, playerY=360;
    private float joyX=0, joyY=0;
    private boolean up,down,left,right, sprint, pass, shoot, tackle;
    private long last=System.nanoTime(), elapsed=0;
    private int homeScore=0, awayScore=0;
    private boolean playing=false, paused=false, goalFlash=false;
    private long goalAt=0;
    private int minute=0;
    private final ArrayList<Player> home=new ArrayList<>(), away=new ArrayList<>();
    private final String[] names={"Samatta","Msuva","Dismas","Chama","Feisal","Mwamnyeto","Job","Yassin","Kibu","Kapombe","Aziz","Mzize"};
    private int selected=0;

    FootballGameView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true); buildTeams(); }

    void buildTeams(){
        home.clear(); away.clear();
        for(int i=0;i<6;i++) home.add(new Player(270+(i%2)*120,180+(i/2)*150,0,i,names[i]));
        for(int i=0;i<6;i++) away.add(new Player(1010-(i%2)*120,180+(i/2)*150,1,i,names[i+6]));
        home.get(0).controlled=true;
    }

    @Override protected void onDraw(Canvas c){
        W=getWidth(); H=getHeight(); sx=W/1280f; sy=H/720f;
        c.save(); c.scale(sx,sy); drawScene(c); c.restore();
        if(playing && !paused){ invalidate(); tick(); }
    }

    void tick(){
        long now=System.nanoTime(); float dt=Math.min(0.04f,(now-last)/1e9f); last=now;
        if(!playing||paused){return;}
        elapsed += (long)(dt*1000);
        minute=(int)Math.min(90, elapsed/1200); // compressed match clock
        float dx=joyX, dy=joyY;
        if(up)dy-=1; if(down)dy+=1; if(left)dx-=1; if(right)dx+=1;
        float len=(float)Math.sqrt(dx*dx+dy*dy); if(len>1){dx/=len;dy/=len;}
        float speed=(sprint?260:185);
        playerX=clamp(playerX+dx*speed*dt,95,1185); playerY=clamp(playerY+dy*speed*dt,105,615);
        if(pass){ kick(430); pass=false; }
        if(shoot){ kick(680); shoot=false; }
        if(tackle){ tackle=false; }
        ballXUpdate(dt);
        ai(dt);
        if(minute>=90){playing=false; paused=false;}
    }

    void kick(float power){
        float dx=bx-playerX,dy=by-playerY,d=(float)Math.sqrt(dx*dx+dy*dy);
        if(d<90){ if(d<1)d=1; ballVX=dx/d*power; ballVY=dy/d*power; }
    }
    void ballXUpdate(float dt){
        bx+=ballVX*dt; by+=ballVY*dt; ballVX*=0.986f; ballVY*=0.986f;
        if(by<95||by>625){by=clamp(by,95,625);ballVY*=-.65f;}
        if(bx<75||bx>1205){ 
            if(by>285&&by<435){ if(bx<75)awayScore++; else homeScore++; goalFlash=true;goalAt=System.currentTimeMillis(); }
            bx=640;by=360;ballVX=0;ballVY=0;
        }
    }
    void ai(float dt){
        for(Player q:home) if(q!=home.get(selected)){
            float tx=bx,ty=by; moveAI(q,tx,ty,dt,0);
        }
        for(Player q:away) moveAI(q,bx,by,dt,1);
        if(distance(playerX,playerY,bx,by)<38 && Math.abs(ballVX)+Math.abs(ballVY)<120){ bx=playerX+joyX*25;by=playerY+joyY*25; }
    }
    void moveAI(Player q,float tx,float ty,float dt,int team){
        float dx=tx-q.x,dy=ty-q.y,d=(float)Math.sqrt(dx*dx+dy*dy);
        if(d>35){q.x+=dx/d*(team==0?85:78)*dt;q.y+=dy/d*(team==0?85:78)*dt;}
        q.x=clamp(q.x,100,1180);q.y=clamp(q.y,110,610);
    }

    void drawScene(Canvas c){
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(5,20,14));c.drawRect(0,0,1280,720,p);
        if(!playing){ drawMenu(c); return; }
        drawPitch(c); drawPlayers(c); drawBall(c); drawHud(c); drawControls(c);
        if(paused){p.setColor(0xB8000000);c.drawRect(0,0,1280,720,p);text(c,"PAUSED",640,300,48,Color.WHITE,Paint.Align.CENTER);button(c,500,350,780,420,"RESUME");}
        if(goalFlash && System.currentTimeMillis()-goalAt<1200){text(c,"GOAL!",640,260,72,Color.rgb(255,215,70),Paint.Align.CENTER);invalidate();}
        else goalFlash=false;
    }

    void drawMenu(Canvas c){
        p.setColor(Color.rgb(6,35,24));c.drawRect(0,0,1280,720,p);
        // stadium glow
        for(int i=0;i<12;i++){p.setColor(0x1038C172);c.drawCircle(80+i*110,80,55,p);}
        text(c,"TAYODE",640,145,76,Color.rgb(212,175,55),Paint.Align.CENTER);
        text(c,"FOOTBALL™",640,210,48,Color.WHITE,Paint.Align.CENTER);
        text(c,"BUILD 01.48  •  OFFLINE MATCH ENGINE",640,248,18,0xFFB8C9C0,Paint.Align.CENTER);
        button(c,390,305,890,380,"KICK OFF");
        button(c,390,400,610,465,"TEAMS");
        button(c,670,400,890,465,"SETTINGS");
        text(c,"Android 9+  •  No internet required for gameplay",640,560,18,0xFFD4E2DA,Paint.Align.CENTER);
        text(c,"TAYODE FOOTBALL",640,620,20,Color.rgb(212,175,55),Paint.Align.CENTER);
    }

    void drawPitch(Canvas c){
        p.setColor(Color.rgb(25,112,58));c.drawRect(55,75,1225,650,p);
        for(int i=0;i<10;i++){p.setColor(i%2==0?0x181B9B4D:0x10000000);c.drawRect(55+i*117,75,55+(i+1)*117,650,p);}
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xFFE9F4E9);
        c.drawRect(75,95,1205,630,p);c.drawLine(640,95,640,630,p);c.drawCircle(640,362,85,p);
        c.drawRect(75,250,215,475,p);c.drawRect(1065,250,1205,475,p);
        c.drawRect(75,300,135,425,p);c.drawRect(1145,300,1205,425,p);
        p.setStyle(Paint.Style.FILL);
    }
    void drawPlayers(Canvas c){
        for(Player q:home) drawPlayer(c,q,Color.rgb(20,65,180));
        for(Player q:away) drawPlayer(c,q,Color.rgb(190,30,35));
        // controlled ring
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(255,220,70));c.drawCircle(playerX,playerY,30,p);p.setStyle(Paint.Style.FILL);
    }
    void drawPlayer(Canvas c,Player q,int kit){
        float x=q==home.get(selected)?playerX:q.x, y=q==home.get(selected)?playerY:q.y;
        p.setColor(0x40000000);c.drawOval(x-18,y+17,x+18,y+28,p);
        p.setColor(kit);c.drawRoundRect(x-15,y-2,x+15,y+26,8,8,p);
        int[] skins={0xFF6D4428,0xFF9A633E,0xFFB8784D,0xFFD29A70,0xFF5A351F};
        p.setColor(skins[q.index%skins.length]);c.drawCircle(x,y-15,13,p);
        p.setColor(Color.rgb(30,20,15));c.drawArc(x-13,y-28,x+13,y-5,180,180,true,p);
        text(c,String.valueOf(q.number),x,y+18,11,Color.WHITE,Paint.Align.CENTER);
    }
    void drawBall(Canvas c){
        p.setColor(0x55000000);c.drawCircle(bx+3,by+5,9,p);p.setColor(Color.WHITE);c.drawCircle(bx,by,9,p);
        p.setColor(Color.DKGRAY);c.drawCircle(bx,by,2.5f,p);
    }
    void drawHud(Canvas c){
        p.setColor(0xD90A1D14);c.drawRoundRect(455,12,825,68,18,18,p);
        text(c,"TAYODE UNITED",540,47,18,Color.WHITE,Paint.Align.CENTER);
        text(c,homeScore+"  -  "+awayScore,640,51,28,Color.rgb(255,215,70),Paint.Align.CENTER);
        text(c,"STARS XI",740,47,18,Color.WHITE,Paint.Align.CENTER);
        text(c,String.format("%02d:%02d",minute%91, (int)((elapsed/20)%60)),640,92,16,Color.WHITE,Paint.Align.CENTER);
        text(c,"☰",1205,48,28,Color.WHITE,Paint.Align.CENTER);
    }
    void drawControls(Canvas c){
        p.setColor(0x55202020);c.drawCircle(130,575,72,p);p.setColor(0x8890A89D);c.drawCircle(130+joyX*35,575+joyY*35,28,p);
        control(c,1020,525,110,"PASS","P"); control(c,1150,470,110,"SHOOT","S"); control(c,1130,590,90,"SPRINT","R"); control(c,1000,620,90,"TACKLE","T");
    }
    void control(Canvas c,float x,float y,float r,String label,String key){
        p.setColor(0xAA071A12);c.drawCircle(x,y,r/2,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFFD4AF37);c.drawCircle(x,y,r/2,p);p.setStyle(Paint.Style.FILL);
        text(c,key,x,y+7,25,Color.WHITE,Paint.Align.CENTER);text(c,label,x,y+r/2+19,13,Color.WHITE,Paint.Align.CENTER);
    }
    void button(Canvas c,float l,float t,float r,float b,String s){
        p.setColor(0xFF102E20);c.drawRoundRect(l,t,r,b,18,18,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xFFD4AF37);c.drawRoundRect(l,t,r,b,18,18,p);p.setStyle(Paint.Style.FILL);
        text(c,s,(l+r)/2,(t+b)/2+9,24,Color.WHITE,Paint.Align.CENTER);
    }
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setTextSize(size);p.setColor(color);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
    static float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    static float distance(float a,float b,float c,float d){return (float)Math.hypot(a-c,b-d);}

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        float x=e.getX()/sx,y=e.getY()/sy;
        int act=e.getActionMasked();
        if(!playing){
            if(act==MotionEvent.ACTION_UP && x>380&&x<900&&y>290&&y<395){ startMatch(); }
            return true;
        }
        if(paused){
            if(act==MotionEvent.ACTION_UP&&x>480&&x<800&&y>340&&y<430){paused=false;last=System.nanoTime();}
            return true;
        }
        if(act==MotionEvent.ACTION_DOWN||act==MotionEvent.ACTION_MOVE){
            if(x<250&&y>480){joyX=clamp((x-130)/65f,-1,1);joyY=clamp((y-575)/65f,-1,1);}
            if(distance(x,y,1020,525)<65)pass=true;
            if(distance(x,y,1150,470)<65)shoot=true;
            if(distance(x,y,1130,590)<55)sprint=true;
            if(distance(x,y,1000,620)<55)tackle=true;
            if(x>1160&&y<90)paused=true;
        } else if(act==MotionEvent.ACTION_UP){
            joyX=joyY=0;sprint=false;
            if(distance(x,y,1020,525)<65)pass=true;
            if(distance(x,y,1150,470)<65)shoot=true;
            if(distance(x,y,1000,620)<55)tackle=true;
        }
        return true;
    }
    void startMatch(){playing=true;paused=false;elapsed=0;minute=0;homeScore=awayScore=0;bx=640;by=360;ballVX=ballVY=0;playerX=350;playerY=360;buildTeams();last=System.nanoTime();invalidate();}
    static class Player{
        float x,y;int team,index,number;String name;boolean controlled;
        Player(float x,float y,int t,int i,String n){this.x=x;this.y=y;team=t;index=i;number=7+i;name=n;}
    }
}
