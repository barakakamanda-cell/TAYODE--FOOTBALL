@echo off
setlocal
set "APP_HOME=%~dp0"
if not defined JAVA_HOME (
  set "JAVACMD=java.exe"
) else (
  set "JAVACMD=%JAVA_HOME%\bin\java.exe"
)
"%JAVACMD%" -jar "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" %*
exit /b %ERRORLEVEL%
