# TAYODE FOOTBALL™ — BUILD 01.48

Playable Android offline football game foundation.

## Implemented
- Full-screen landscape match scene
- Offline local gameplay; no network required after installation
- Touch joystick movement
- PASS, SHOOT, SPRINT and TACKLE controls
- Ball physics, possession/kick interaction and goal detection
- Opponent and teammate basic AI movement
- Match clock and score
- Pause/resume
- Procedural pitch, players, kits, heads/hair and HUD graphics drawn on-device
- Local player/team JSON retained in `assets/players.json`
- Android 9+ (API 28+), target SDK 35
- No third-party runtime dependencies

## Important scope
This build is a playable 2D/offline game, not a finished AAA 3D simulation. Real-player likenesses, licensed club logos/kits, stadium 3D assets, commentary, career/league systems and advanced animation require additional content and licensing/assets. They are not falsely represented as included.

## Build
From the project root:
`gradle assembleDebug`
or use the repository's GitHub Actions workflow.
